package com.example.brasserie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrasserieApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrasserieApplication.class, args);
	}

}
