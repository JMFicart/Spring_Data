package com.example.brasserie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrasserieApplicationTests {

	@Test
	void contextLoads() {
	}

}
