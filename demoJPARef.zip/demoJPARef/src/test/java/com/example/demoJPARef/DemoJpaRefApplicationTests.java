package com.example.demoJPARef;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaRefApplicationTests {

	@Test
	void contextLoads() {
	}

}
