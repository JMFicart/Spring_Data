package com.example.demoJPARef;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaRefApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpaRefApplication.class, args);
	}

}
